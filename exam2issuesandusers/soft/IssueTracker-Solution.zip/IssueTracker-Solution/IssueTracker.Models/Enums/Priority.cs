﻿namespace IssueTracker.Models.Enums
{
    public enum Priority
    {
        Low,
        Medium,
        High
    }
}
