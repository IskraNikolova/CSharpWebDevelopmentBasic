﻿namespace IssueTracker.Models.Enums
{
    public enum Role
    {
        Regular,
        Administrator
    }
}
