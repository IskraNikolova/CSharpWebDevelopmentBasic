﻿namespace IssueTracker.Models.Enums
{
    public enum Status
    {
        New,
        Solved
    }
}
