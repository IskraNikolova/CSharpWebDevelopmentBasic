﻿namespace IssueTracker.Models.BindingModels
{
    public class NewIssueBindingModel
    {
        public string Name { get; set; }

        public string Status { get; set; }

        public string Priority { get; set; }

    }
}
