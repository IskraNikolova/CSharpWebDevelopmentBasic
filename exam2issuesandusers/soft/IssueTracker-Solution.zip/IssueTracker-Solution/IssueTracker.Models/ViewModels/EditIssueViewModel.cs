﻿namespace IssueTracker.Models.ViewModels
{
    public class EditIssueViewModel
    {
        public LoggedInUserViewModel LoggedInUserViewModel { get; set; }

        public int Id { get; set; }
    }
}
