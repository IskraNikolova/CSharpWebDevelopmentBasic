﻿namespace IssueTracker.Models.ViewModels
{
    public class LoggedInUserViewModel
    {

        public string Username { get; set; }

        public bool IsAdmin { get; set; }
    }
}
